console.log("visa bot çalışıyor 💖");

// Basit test sunucusu
const http = require("http");

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Visa bot aktif 💖");
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log(`Server çalışıyor: ${PORT}`);
});
